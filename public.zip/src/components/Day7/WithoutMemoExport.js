import React from 'react'

const WithoutMemoExport = () => {
    console.log("1.WithoutMemoExport")
  return (
    <div>1.WithoutMemoExport</div>
  )
}

export default WithoutMemoExport