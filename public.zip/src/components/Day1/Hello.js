import React from 'react'

const Hello = () => {
  return (
    <div>Hello onpassive</div>
  )
}

export default Hello