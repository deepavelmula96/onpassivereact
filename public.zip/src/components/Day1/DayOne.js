import React from 'react'

const DayOne = () => {
  return (
    <div>DayOne</div>
  )
}

export default DayOne