import React from 'react'
import UseEffectHook from './UseEffectHook'

const DayTwo = () => {
  return (
    <div>DayTwo
        {/* 1. useState */}
        {/* 2. useEffect */}
        <UseEffectHook/>

    </div>
  )
}

export default DayTwo