import React from 'react'
import Formex from './Formex'
import InputTypeCheckbox from './InputTypeCheckbox'
import InputTypeMultileCheckbox from './InputTypeMultileCheckbox'
import InputTypeRadio from './InputTypeRadio'
import InputTypeText from './InputTypeText'
import InputTypeTextArea from './InputTypeTextArea'
import SelectTag from './SelectTag'

const DayThree = () => {
  return (
    <div>DayThree
        {/* <InputTypeText/> */}
        {/* <InputTypeTextArea/> */}
        {/* <InputTypeCheckbox/> */}
        {/* <InputTypeMultileCheckbox/> */}
        {/* <InputTypeRadio/> */}
        {/* <SelectTag/> */}
        <Formex/>
    </div>
  )
}

export default DayThree