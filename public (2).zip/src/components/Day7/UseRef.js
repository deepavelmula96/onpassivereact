import React from 'react'
import RefPropertiesTag from './RefPropertiesTag'

const UseRef = () => {
  return (
    <div>UseRef
      <RefPropertiesTag/>
    </div>
  )
}

export default UseRef