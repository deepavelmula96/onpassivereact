import React from 'react'
import AxiosTopic from './AxiosTopic'
import ControlledvsUncontrolled from './ControlledvsUncontrolled/ControlledvsUncontrolled'
import GetUsersDetails from './CustomHook/GetUsersDetails'

const DayNine = () => {
  return (
    <div>DayNine
      {/* <ControlledvsUncontrolled/> */}
      {/* <AxiosTopic/> */}
      <GetUsersDetails/>
    </div>
  )
}

export default DayNine