import React from 'react'

const Hi = () => {
  return (
    <div>Hi</div>
  )
}

export default Hi