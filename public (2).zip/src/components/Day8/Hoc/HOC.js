import React from 'react'
import HOCparent from './HOCparent'
import HocAuthentificationParent from './HocAuthentificationParent'

const HOC = () => {
    return (
        <div>HOC
            it is used for reuse the component logic
            {/* <HOCparent /> */}
            authentication example
            {/* <HocAuthentificationParent/> */}

        </div>
    )
}

export default HOC