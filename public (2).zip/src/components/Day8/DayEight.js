import React from 'react'
import FormWithValidation from './FormWithValidation'
import FormWithValidationOnblur from './FormWithValidationOnblur'
import HOC from './Hoc/HOC'
import OnBlurForm from './OnBlurForm'
import RegistrationForm from './RegistrationForm'
import SingleFieldOnBlur from './SingleFieldOnBlur'

const DayEight = () => {
  return (
    <div>DayEight
        {/* <FormWithValidation/> */}
        {/* <FormWithValidationOnblur/> */}
        {/* <RegistrationForm/> */}
        {/* <OnBlurForm/> */}
        {/* <SingleFieldOnBlur/> */}
        <HOC/>
    </div>
  )
}

export default DayEight