import React from 'react'
import ContextApi from './ContextApi'

const DayFour = () => {
  return (
    <div>DayFour
        <ContextApi/>
    </div>
  )
}

export default DayFour