import React from 'react'
import MobileComponent from './MobileComponent'

const DayFive = () => {
  return (
    <div>DayFive
        <MobileComponent/>
    </div>
  )
}

export default DayFive