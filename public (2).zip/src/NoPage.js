import React from 'react'

const NoPage = () => {
  return (
    <div>No Page found</div>
  )
}

export default NoPage